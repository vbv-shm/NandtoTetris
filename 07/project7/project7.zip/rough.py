a=[1,2,3,4]
print(a[-1])
print(12 and 190)
print(not 5232)